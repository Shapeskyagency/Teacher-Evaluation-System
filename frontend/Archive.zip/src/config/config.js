module.exports={
    // baseURL:"http://localhost:8000/api/",
    // baseURL:"https://evaluationapi.dlps.co.in/api/",
    baseURL:"https://api.dlws.edu.in/api/",
    // baseURL:"https://dekhooo.com/api/",
    // baseURL:"http://148.135.136.129/api",
    // baseURL:"https://teacher-evaluation-system-t4rh.onrender.com/api",
    UserRole:["Superadmin","Observer","Teacher"]
}
