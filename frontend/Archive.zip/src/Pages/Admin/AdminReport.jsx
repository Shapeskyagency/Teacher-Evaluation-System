import React from 'react'

const AdminReport = () => {
  return (
    <div>AdminReport</div>
  )
}

export default AdminReport