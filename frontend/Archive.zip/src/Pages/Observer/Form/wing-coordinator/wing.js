export const inputsWing =[
      "planning, coordinating for smooth conduct of morning assembly",
      "ensuring that club and house periods are attended by students and teachers",
      "anecdotal and cumulative records checked (class & section)",
      "winners of class smiley and reasons",
      "number of pd sessions attended by wc and team",
      "experiential think rooms / micro teaching session attended",
      "result discussion: key outcomes",
      "number of individual meetings organised with parents (online/offline) w.r.t academics- behaviour-",
      
      "number of care calls done wing wise (if required)",
      
      "number of reflections forms filled in your wing",
      
      "date last checked for syllabus completion",
      
      "review the weekly lesson plans and update the online tracker (only for pre nur-kg, i-iii, xi-xii)",
      
      "any concerns flagged during dispersal",
      
      "any safety concerns observed",
      
      "hygienic concerns (washrooms)",
      
      "something to share (+ve / -ve)",
      
  ]