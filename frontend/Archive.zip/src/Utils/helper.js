export const withoutAuthRoute = [
    "login",
    "register",
  ];