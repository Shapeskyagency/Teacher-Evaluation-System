import { SyncOutlined } from '@ant-design/icons'
import React from 'react'

function UnderConstraction() {
  return (
    <div className='pt-5'>
        <h1>This page is Under  Construction</h1>
        <img className='img-fluid w-50' src='./images/progress.png'/>
    </div>
  )
}

export default UnderConstraction