export const questions = [
    { name: "Class Cleanliness", key: "classCleanliness" },
    { name: "News Update", key: "newsUpdate" },
    { name: "Smiley Chart", key: "smileyChart" },
    { name: "Mission English Chart", key: "missionEnglishChart" },
    { name: "Transport Corner", key: "transportCorner" },
    { name: "General Discipline", key: "generalDiscipline" },
    { name: "Lunch Etiquettes", key: "lunchEtiquettes" },
    { name: "Birthday Chart", key: "birthdayChart" },
    { name: "Unit Syllabus Chart", key: "unitSyllabusChart" },
    { name: "Uniform-Tie, Belt, Shoes, I.Card", key: "uniformTieBeltShoesICard" },
    { name: "Class Pass", key: "classPass" },
    { name: "Class/Teacher's Time Table", key: "classTeacherTimeTable" },
    { name: "Participation Chart", key: "participationChart" },
    { name: "Co-scholastic Activity Chart (PA, PE, CA)", key: "coScholasticActivityChart" },
    { name: "Goodwill Piggy Bank", key: "goodwillPiggyBank" },
    { name: "Thursday Special", key: "thursdaySpecial" },
    { name: "Homework Register / AQAD Register", key: "homeworkRegisterAQADRegister" },
    { name: "Is there a Group on Duty", key: "isGroupOnDuty" },
    { name: "Is there weekly Rotation of Student", key: "isWeeklyRotationOfStudents" },
    { name: "Anecdotal Register", key: "anecdotalRegister" },
    { name: "Supplementary Reading Record", key: "supplementaryReadingRecord" },
    { name: "Think Zone", key: "thinkZone" },
    { name: "Digital citizenship rules", key: "digitalCitizenshipRules" },
    { name: "Meditation", key: "meditation" }
  ];
  

  export const questions2 = [
    { name: "Class Cleanliness", key: "classCleanliness" },
    { name: "News Update", key: "newsUpdate" },
    { name: "Smiley Chart", key: "smileyChart" },
    { name: "Mission English Chart", key: "missionEnglishChart" },
    { name: "Transport Corner", key: "transportCorner" },
    { name: "General Discipline", key: "generalDiscipline" },
    { name: "Lunch Etiquettes", key: "lunchEtiquettes" },
    { name: "Birthday Chart", key: "birthdayChart" },
    { name: "Unit Syllabus Chart", key: "unitSyllabusChart" },
    { name: "Uniform-Tie, Belt, Shoes, I.Card", key: "uniformTieBeltShoesICard" },
    { name: "Class Pass", key: "classPass" },
    { name: "Class/Teacher's Time Table", key: "classTeacherTimeTable" },
    { name: "Participation Chart", key: "participationChart" },
    { name: "Co-scholastic Activity Chart (PA, PE, CA)", key: "coScholasticActivityChart" },
    { name: "Goodwill Piggy Bank", key: "goodwillPiggyBank" },
    { name: "Thursday Special", key: "thursdaySpecial" },
    { name: "Homework Register / AQAD Register", key: "homeworkRegisterAQADRegister" },
    { name: "Is there a Group on Duty", key: "isGroupOnDuty" },
    { name: "Is there weekly Rotation of Student", key: "isWeeklyRotationOfStudents" },
    { name: "Anecdotal Register", key: "anecdotalRegister" },
    { name: "Supplementary Reading Record", key: "supplementaryReadingRecord" },
    { name: "Think Zone", key: "thinkZone" },
    { name: "Digital citizenship rules", key: "digitalCitizenshipRules" },
    { name: "Meditation", key: "meditation" }
  ];

  
 
  