import React from 'react'

function InitiateBasicDetails() {
  return (
    <div>InitiateBasicDetails</div>
  )
}

export default InitiateBasicDetails