import React from 'react'

function NotFound404() {
  return (
    <div className='pt-5'>
        <h2>Page Not Found</h2>
    </div>
  )
}

export default NotFound404