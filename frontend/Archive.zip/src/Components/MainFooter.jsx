import React from 'react'

function MainFooter() {
  return (
    <div>Footer</div>
  )
}

export default MainFooter