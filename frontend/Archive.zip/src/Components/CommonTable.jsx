import React from 'react'

function CommonTable() {
  return (
    <div>
        
    </div>
  )
}

export default CommonTable